let shou = [
  { titleImage: "/images/shou/1fe4829408bdaa2769c0c64d23e3c74.png" },
  { titleImage: "/images/shou/d612b8599e7fc024c6ed92dfa07560a.png" },
  { titleImage: "/images/shou/051ad75c7729df2deb5223a54e7ab3b.png" }
]
module.exports = { shou }
